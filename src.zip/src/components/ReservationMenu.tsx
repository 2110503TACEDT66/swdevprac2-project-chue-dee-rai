import styles from './reservationmenu.module.css'

export default function ReservationMenu () {
	return (
		<div className={styles.submenu}>
			Sub-Menu Here
		</div>
	);
}